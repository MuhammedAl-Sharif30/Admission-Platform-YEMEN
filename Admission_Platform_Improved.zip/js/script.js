
function showMessage() {
  alert("مرحباً! سيتم تفعيل المزايا قريباً.");
}
